(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_next_08w7ahn._.js","static/chunks/node_modules_@supabase_auth-js_dist_module_1vqrmkg._.js","static/chunks/node_modules_0khg_c4._.js","static/chunks/src_17ezved._.js","static/chunks/[root-of-the-server]__0cbk-n2._.css"],
    source: "dynamic"
});
